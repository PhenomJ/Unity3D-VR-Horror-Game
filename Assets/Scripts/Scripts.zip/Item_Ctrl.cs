﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Item_Ctrl : MonoBehaviour
{
    VRLookAtObjectBase lookatbase;
    public Item_Management item;
    static int keycount = 0;
    private void Awake()
    {
        lookatbase = GetComponent<VRLookAtObjectBase>();
    }

    private void OnEnable()
    {
        lookatbase.ButtonFillFinish += ButtonFillFinish;
    }

    private void OnDisable()
    {
        lookatbase.ButtonFillFinish -= ButtonFillFinish;
    }

    void ButtonFillFinish()
    {
        keycount++;
        item.GetKeys(keycount);
        Debug.LogWarning("Item keycount value : " + keycount);
        gameObject.SetActive(false);
    }

    
    
}