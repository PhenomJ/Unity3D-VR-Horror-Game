﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item_Management : MonoBehaviour {
    int KeyCount;

    public void GetKeys(int keycount)
    {
        KeyCount = keycount;
        Debug.LogWarning("Management keycount value : " + KeyCount);
    }

    public int Keynumber
    {
        get { return KeyCount; }
    }
}
