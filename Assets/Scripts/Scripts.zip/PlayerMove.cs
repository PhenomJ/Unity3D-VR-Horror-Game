﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour {

    Transform bodytransform;
    float z = 0.0f;
    Vector3 fixedrotation;
    public float movespeed;
    public Transform cameratransform;

    void Start () {
        bodytransform = gameObject.GetComponent<Transform>();
        fixedrotation = new Vector3(0.0f, 0.0f, 0.0f);
    }

	void Update () {

        if (Input.GetButton("Fire1")) {z = movespeed;}
        else { z = 0.0f; }

        Vector3 direction = new Vector3(0.0f, 0.0f, z);
        direction = cameratransform.TransformDirection(direction);
        direction.y = 0.0f;
        bodytransform.position += (direction * Time.deltaTime);
        bodytransform.eulerAngles = fixedrotation;
    }
}
